# Summary

- [Home](README.md)

# Getting started

- [Administrator configuration](admin/configuration.md)
  - [First start](admin/first-run.md)
  - [Locked-state unlock](locked-unlock.md)
  - [Configuration and management map](admin/service-map.md)

# Users and access

- [Applications](users/applications.md)
- [Coding agent](users/coding-agent.md)
- [User settings](users/settings.md)
- [Account and permission model](permissions.md)
- [Accounts and access](admin/accounts.md)
- [Trusted superusers](admin/superusers.md)
- [Authentik administration](admin/authentik.md)

# Storage and services

- [CopyParty](admin/copyparty.md)
- [Syncthing](admin/syncthing.md)
- [Storage installation and recovery](admin/storage-recovery.md)
- [Snapshots, replication, and backups](admin/backups.md)
- [Networking and remote access](admin/networking.md)
- [Observability and alerts](admin/observability.md)
- [Maintenance, service policy, and updates](admin/maintenance.md)
- [Virtualization, AI, UPS, Vaultwarden, and TFTP](admin/virtualization-ai-power.md)
- [Pi coding agent](admin/coding-agent.md)

# Validation and recovery

- [Recovery runbook](reference/project-RECOVERY.md)

# Reference

- [Generated NAS command help](reference/commands.md)
  - [Platform and upstream command help](reference/platform-command-help.md)
  - [Installed component versions](reference/installed-versions.md)
  - [Web interfaces and endpoints](reference/interfaces.md)
  - [Runtime paths and backup ownership](reference/runtime-paths.md)
  - [NAS and AI Nix option source](reference/nix-options-source.md)
  - [Deployed custom configuration source](reference/configuration-source.md)
  - [Cockpit UI source](reference/cockpit-source.md)
  - [Authentik blueprint source](reference/authentik-nas-user-settings-blueprint.md)
  - [CopyParty global help](reference/copyparty-help.md)
  - [CopyParty volume flags](reference/copyparty-flags.md)
  - [Disko OS-disk example](reference/disko-os-disk-example.md)
  - [Disko fresh-pool example](reference/disko-fresh-pool-example.md)
  - [Pool-layout worksheet](reference/pool-layout.md)
- [Project documents](reference/project-documents.md)
  - [README](reference/project-README.md)
  - [Security model](reference/project-SECURITY.md)
  - [Changelog](reference/project-CHANGELOG.md)
