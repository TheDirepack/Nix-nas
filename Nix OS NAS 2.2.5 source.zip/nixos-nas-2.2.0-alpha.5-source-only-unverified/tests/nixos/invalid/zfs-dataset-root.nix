{ ... }:
{ nas.zfsDataset = "tank"; }
