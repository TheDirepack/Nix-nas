{ ... }:
{ nas.trustedInterfaces = [ "lo" ]; }
