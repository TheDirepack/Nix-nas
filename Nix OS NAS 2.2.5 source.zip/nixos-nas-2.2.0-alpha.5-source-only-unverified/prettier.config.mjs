export default {
  bracketSpacing: false,
  printWidth: 100,
  proseWrap: "preserve",
  semi: true,
  singleQuote: false,
  trailingComma: "all",
};
